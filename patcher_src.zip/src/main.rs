mod lib;
use byteorder::{LittleEndian, ReadBytesExt};
use lib::{cpk::CPK, iso::ISO, util::BinaryStruct};
use std::{
    cmp::Ordering,
    ffi::OsStr,
    fs::{File, OpenOptions},
    io::{Seek, SeekFrom, Write},
    path::{Path, PathBuf},
};

use crate::lib::event::EventArch;

#[derive(Debug)]
#[repr(C)]
pub struct PgdDesc {
    vkey: [u8; 16],
    dkey: [u8; 16],
    open_flags: u32,
    key_index: u32,
    drm_type: u32,
    mac_type: u32,
    cipher_type: u32,
    data_size: u32,
    align_size: u32,
    block_size: u32,
    block_nr: u32,
    data_offset: u32,
    table_offset: u32,
    block_buf: *mut u8,
    current_block: u32,
    file_offset: u32,
}
extern "C" {
    pub fn pspDecryptPRX(
        inbuf: *const cty::uint8_t,
        outbuf: *mut cty::uint8_t,
        size: cty::uint32_t,
    ) -> cty::c_int;
    pub fn pgd_open(
        pgd_buf: *mut cty::uint8_t,
        flag: cty::c_int,
        key: *mut cty::uint8_t,
    ) -> *mut PgdDesc;
    pub fn kirk_init() -> cty::c_void;
    pub fn pgd_decrypt_block(pgd: *mut PgdDesc, block: cty::c_int) -> cty::c_int;
    pub fn pgd_close(pgd: *mut PgdDesc) -> cty::c_int;
}

#[allow(dead_code)]
fn extract_iso(path: &Path) -> std::io::Result<String> {
    println!("Extracting iso");
    let file = File::open(path)?;
    let mut iso = ISO::new(file);
    iso.extract(Path::new("./iso/"))?;
    let pvd = iso.get_pvd()?;
    let name = String::from_utf8(pvd.data[1..11].to_vec()).unwrap();
    Ok(name)
    // pvd.
}

#[allow(dead_code)]
fn apply_xdelta_patch(src: &Path, patch: &Path) -> std::io::Result<()> {
    println!("Applying patch {}", patch.to_str().unwrap());
    let patch_data = std::fs::read(patch)?;
    let data = std::fs::read(src)?;
    let res = xdelta3::decode(&patch_data, &data);
    match res {
        Some(patched) => std::fs::write(src, &patched),
        None => panic!("Failed to apply patch {}", patch.to_str().unwrap()),
    }
}
#[allow(dead_code)]
fn apply_misc_patches(game: &str) -> std::io::Result<()> {
    let patches = vec![("iso/PSP_GAME/SYSDIR/", "EBOOT.BIN")];
    patches.into_iter().try_for_each(|x| {
        let mut path: PathBuf = x.0.into();
        path.push(x.1);
        let mut patch_path = PathBuf::from("dist/");
        patch_path.push(game);
        patch_path.push(&format!("{}.patch", x.1));
        apply_xdelta_patch(&path, &patch_path)
    })
}
fn decrypt_eboot() -> std::io::Result<()> {
    let eboot = std::fs::read("iso/PSP_GAME/SYSDIR/EBOOT.BIN")?;
    let magic = [0x7fu8, 0x45, 0x4c, 0x46];
    let output = if let Ordering::Equal = eboot[0x0..0x4].cmp(&magic) {
        eboot
    } else {
        let elf_size = (&eboot[0x28..0x30]).read_u32::<LittleEndian>()?;
        let psp_size = (&eboot[0x2c..0x30]).read_u32::<LittleEndian>()?;
        let size = elf_size.max(psp_size);
        let mut output = vec![0; size as usize];
        let res = unsafe { pspDecryptPRX(eboot.as_ptr(), output.as_mut_ptr(), size) };
        if res < 0 {
            panic!("Unable to decrypt eboot.");
        }
        while output.len() > res as usize {
            output.pop();
        }
        output
    };
    std::fs::write("iso/PSP_GAME/SYSDIR/EBOOT.BIN", &output)
}

#[allow(dead_code)]
fn extract_cpk(game: &str) -> std::io::Result<()> {
    std::fs::create_dir_all("cpk")?;
    let mut file = File::open("iso/PSP_GAME/USRDIR/pack/P2PT_ALL.cpk")?;
    let mut cpk = CPK::read(&mut file)?;
    cpk.map_files(&mut file, |x, y| {
        println!("Extract cpk file [{}]{}", x.id, x.name);
        let patch_path = PathBuf::from(format!("dist/{}/cpk_dist/{}.bin.patch", game, &x.id));
        let out_data = if patch_path.exists() {
            let patch_data = std::fs::read(&patch_path)?;
            let res = xdelta3::decode(&patch_data, &y);
            match res {
                Some(patched) => patched,
                None => panic!("Failed to apply patch {}", patch_path.to_str().unwrap()),
            }
        } else {
            y
        };
        std::fs::write(format!("cpk/{}.bin", x.id), out_data)
    })
}

#[allow(dead_code)]
fn build_cpk() -> std::io::Result<()> {
    // let mut file = File::open("P2PT_ALL.cpk")?;
    let mut file = File::open("iso/PSP_GAME/USRDIR/pack/P2PT_ALL.cpk")?;
    let mut cpk = CPK::read(&mut file)?;
    let mut out = OpenOptions::new()
        .create(true)
        .write(true)
        .read(true)
        .truncate(true)
        .open("iso/PSP_GAME/USRDIR/pack/P2PT_ALL.cpk")?;

    cpk.write_cpk(PathBuf::from("cpk/"), &mut out)
}

#[allow(dead_code)]
fn patch_event(game: &str) -> std::io::Result<()> {
    let data = std::fs::read("cpk/6000.bin")?;
    let mut event: EventArch = EventArch::try_from(data)?;

    event.map_scripts(|name, event| {
        let patch_path = PathBuf::from(format!("dist/{}/event_dist/{}.patch", game, &name));
        Ok(if patch_path.exists() {
            let patch_data = std::fs::read(&patch_path)?;
            let res = xdelta3::decode(&patch_data, event);
            match res {
                Some(patched) => {
                    // std::fs::write(format!("event/{}.bin", &name), &patched)?;
                    Some(patched)
                }
                None => panic!("Failed to apply patch {}", patch_path.to_str().unwrap()),
            }
        } else {
            None
        })
    })?;

    let mut output = OpenOptions::new()
        .create(true)
        .write(true)
        .read(true)
        .truncate(true)
        .open("cpk/6000.bin")?;
    let toc = event.write(&mut output)?;

    let mut eboot = OpenOptions::new()
        .read(true)
        .write(true)
        .truncate(false)
        .open("iso/PSP_GAME/SYSDIR/EBOOT.BIN")?;
    let addr = match game {
        "ULUS-10584" => 0x8bbc910,
        "ULES-01557" => 0x8bbcb54,
        _ => panic!("Unknown region {}", game),
    };
    eboot.seek(SeekFrom::Start(addr + 0xc0 - 0x8804000))?;
    eboot.write_all(&toc)?;
    // eboot.write_all_at(&toc, 0x8c570c4 + 0xc0 - 0x8804000)?;

    Ok(())

    // dbg!(&event);
    // let file = File::open("cpk/6000.bin")?;

    // Ok(())
}

#[allow(dead_code)]
fn build_iso(path: &Path) -> std::io::Result<()> {
    println!("Building iso... This may take a minute");
    let original = File::open(path)?;
    let out = OpenOptions::new()
        .create(true)
        .write(true)
        .read(true)
        .truncate(true)
        .open("P2IS_modded.iso")?;

    let mut old_iso = ISO::new(original);
    let mut iso = ISO::new(out);
    let pvd = old_iso.get_pvd()?;
    iso.build_from_dir(pvd, PathBuf::from("iso/"))?;

    Ok(())
    // cpk.write_cpk(PathBuf::from("cpk/"), &mut out)
}
fn cleanup() -> std::io::Result<()> {
    std::fs::remove_dir_all("iso")?;
    std::fs::remove_dir_all("cpk")
}

fn decrypt_edat(mut file: Vec<u8>) -> std::io::Result<Vec<u8>> {
    // let mut file = std::fs::read(path)?;
    unsafe {
        kirk_init();
        let desc_ptr = pgd_open(file.as_mut_ptr().wrapping_add(0x90), 2, 0 as *mut u8);
        if desc_ptr == std::ptr::null_mut() {
            panic!()
        }
        let desc = &*desc_ptr;

        let block_size = desc.block_size as usize;

        let data_slice = &mut file[(0x90 + desc.data_offset as usize)
            ..(0x90 + (desc.data_offset + desc.data_size) as usize)];
        let mut rem = data_slice.len();
        for i in 0..desc.block_nr as usize {
            std::ptr::write_bytes(desc.block_buf, 0, block_size);
            std::ptr::copy_nonoverlapping(
                data_slice[i * block_size..].as_ptr(),
                desc.block_buf,
                block_size.min(rem),
            );
            pgd_decrypt_block(desc_ptr, i as i32);

            std::ptr::copy_nonoverlapping(
                desc.block_buf,
                data_slice[(i * block_size)..].as_mut_ptr(),
                block_size.min(rem),
            );
            rem = rem.saturating_sub(block_size);
        }
        Ok(data_slice.to_vec())
    }
}

fn patch_edat(path: &Path) -> std::io::Result<()> {
    let magic = [0u8, 0x50, 0x47, 0x44];
    let mut edat = std::fs::read(&path)?;
    if let Ordering::Equal = edat[0x90..0x94].cmp(&magic) {
        println!("Decrypting");
        edat = decrypt_edat(edat)?;
    } else {
        println!("Not encrypted!");
    }
    let filename = if let Some(name) = path.file_name().and_then(OsStr::to_str) {
        name
    } else {
        panic!("Invalid filename");
    };

    std::fs::create_dir_all("quests")?;

    let out_path = PathBuf::from(format!("quests/{}", filename));
    let patch_path = PathBuf::from(format!("dist/quests/{}.patch", filename));

    std::fs::write(&out_path, edat)?;
    if patch_path.exists() {
        apply_xdelta_patch(&out_path, &patch_path)?;
    } else {
        println!("No patch found for {}", filename);
    }

    Ok(())
}
fn main() -> std::io::Result<()> {
    let cwd = std::env::current_dir()?;
    for arg in std::env::args().skip(1) {
        let mut path = PathBuf::from(arg);
        std::env::set_current_dir(&cwd)?;
        path = path.canonicalize()?;
        std::env::set_current_dir(std::env::current_exe()?.parent().unwrap())?;
        // let lowercase = path.extension().and_then(f)

        match path.extension().and_then(OsStr::to_str) {
            Some(s) => {
                let lower = s.to_lowercase();
                if let Ordering::Equal = "iso".cmp(&lower) {
                    let region = extract_iso(&path)?;
                    println!("Found region {}", region);
                    decrypt_eboot()?;
                    apply_misc_patches(&region)?;
                    extract_cpk(&region)?;
                    patch_event(&region)?;
                    build_cpk()?;
                    build_iso(&path)?;
                    cleanup()?;
                } else if let Ordering::Equal = "edat".cmp(&lower) {
                    patch_edat(&path)?;
                }
            }
            _ => {
                println!("Unknown file type!");
            }
        }
    }
    println!("Done! Press enter to close..");
    std::io::stdin().read_line(&mut String::new())?;

    Ok(())
}
